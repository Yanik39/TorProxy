# -*- coding: utf-8 -*-

__version__ = "0.4.0-dev1"
__author__ = "Mike Perry"
__license__ = "MIT/Expat"
__url__ = "https://github.com/mikeperry-tor/vanguards"
